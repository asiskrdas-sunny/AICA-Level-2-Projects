# -*- coding: utf-8 -*-
"""
Detailed Project Report
=======================
Project-finance tool for a Term Loan (hotel case study model).

* Enter numbers on the "Assumptions" tab.
* Press "Generate Report" to build:
      - Project Income Statement (with loan schedule, DSCR, IRR, payback, break-even)
      - Projected Balance Sheet
      - Projected Cash Flow Statement
* Save / load assumptions (JSON) and export all reports to Excel.

Libraries used
--------------
Standard library : tkinter, json, os, sys, copy      (ships with Python - nothing to install)
Third-party      : openpyxl  (ONLY needed for "Export to Excel")

Install command (one line, run in CMD):
    python -m pip install openpyxl

Runs directly from IDLE: open this file and press F5.
All amounts are in Rs. Crores unless stated otherwise.
"""

import copy
import json
import os
import sys
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

APP_TITLE = "Detailed Project Report"

# --------------------------------------------------------------------------
# Colour palette (vibrant)
# --------------------------------------------------------------------------
PRIMARY = "#4527A0"    # deep purple
PRIMARY_D = "#311B92"
TEAL = "#00897B"
ORANGE = "#FB8C00"
PINK = "#D81B60"
BLUE = "#1E88E5"
GREEN = "#43A047"
RED = "#E53935"
YELLOW = "#FDD835"
BG = "#F3EFFB"
CARD = "#FFFFFF"

FONT = ("Segoe UI", 10)
FONT_B = ("Segoe UI", 10, "bold")
FONT_S = ("Segoe UI", 9)
FONT_H = ("Segoe UI", 12, "bold")
FONT_T = ("Segoe UI", 22, "bold")

# --------------------------------------------------------------------------
# Default assumptions (taken from "Hotel Case Study Financial Model Aug 2026")
# Percentages are stored as fractions (0.65 = 65 %).
# --------------------------------------------------------------------------
# How each cost item is capitalised for depreciation
CATS = [
    ("land", "Land (not depreciated)"),
    ("building", "Hotel Building"),
    ("equipment", "Kitchen Equipment & Machinery"),
    ("shared", "Shared: Building + Equipment"),
]
CAT_LABEL = dict(CATS)
CAT_KEY = {label: key for key, label in CATS}
MAX_ITEMS = 30
MAX_QUARTERS = 20        # construction period: 1 to 20 quarters (up to 5 years)
MAX_YEARS = 25           # repayment / projection period: 1 to 25 years


def new_item(name="New cost item", cost=0.0, margin=1.0, cat="building", bshare=0.5, phasing=None, nq=8):
    """One project-cost line. margin/bshare/phasing are fractions (0.25 = 25 %).
    phasing holds quarters 1..nq-1; the last quarter is always the balance (100 % - the rest)."""
    return {"name": name, "cost": cost, "margin": margin, "cat": cat, "bshare": bshare,
            "phasing": list(phasing) if phasing is not None else [0.0] * (nq - 1)}


DEFAULTS = {
    "project_name": "Hotel Case Study",
    "start_fy": 2024,
    "quarters": 8,          # construction period in quarters (dynamic: 1 - 20)
    # Cost items are dynamic: rename, add or remove them on the Assumptions tab.
    # Quarters 1-7 are inputs; quarter 8 is the balance (100 % - sum of the rest)
    "items": [
        new_item("Cost of Land [already acquired by the Company]", 20.0, 1.0, "land", 0.5,
                 [1.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00]),
        new_item("Cost of Approvals / Premiums & Regulatory Costs", 10.0, 0.5, "building", 0.5,
                 [0.25, 0.50, 0.10, 0.00, 0.00, 0.00, 0.10]),
        new_item("Cost of Construction of the Hotel Building", 40.0, 0.3, "building", 0.5,
                 [0.10, 0.20, 0.30, 0.35, 0.05, 0.00, 0.00]),
        new_item("Cost of Interiors & Kitchen Equipments", 50.0, 0.25, "equipment", 0.5,
                 [0.00, 0.00, 0.10, 0.10, 0.20, 0.20, 0.30]),
        new_item("Contingency Margin", 7.5, 1.0, "shared", 0.5,
                 [0.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.50]),
    ],
    "rate": 0.10,
    "tax": 0.33,
    "life_bldg": 40.0,
    "life_equip": 15.0,
    "room_share": 0.55,
    "fb_share": 0.30,
    "rooms": 125,
    "days": 365,
    "occ": 0.65,
    "occ_inc": 0.025,
    "occ_cap": 0.80,
    "tariff": 10000.0,
    "tariff_inc": 0.015,
    "exp_fb": 0.075,
    "exp_emp": 0.20,
    "exp_power": 0.06,
    "exp_oth": 0.04,
    "exp_service": 0.05,
    "admin": 0.20,
    "admin_inc": 0.10,
    "tenure": 10,           # term-loan repayment tenure in years (= projection period)
    "installments": 120,    # number of equal installments over the tenure (120 = monthly for 10 years)
}

# key, label, kind, unit text, min, max      (pct inputs are typed as 65 for 65 %)
S_FINANCE = [
    ("rate", "Rate of interest on term loan", "pct", "% p.a.", 0, 100),
    ("tax", "Corporate income tax rate", "pct", "%", 0, 100),
]
S_DEPREC = [
    ("life_bldg", "Useful life - hotel building", "num", "years", 1, 100),
    ("life_equip", "Useful life - kitchen equipment & machinery", "num", "years", 1, 100),
]
S_MIX = [
    ("room_share", "Room revenue", "pct", "% of total", 0.0001, 100),
    ("fb_share", "Food & beverage", "pct", "% of total", 0, 100),
]
S_OPER = [
    ("rooms", "Total number of rooms", "int", "rooms", 1, 100000),
    ("days", "Days in a year rooms are offered", "int", "days", 1, 366),
    ("occ", "Occupancy - first operating year", "pct", "%", 0, 100),
    ("occ_inc", "Yearly increase in occupancy", "pct", "% points", 0, 100),
    ("occ_cap", "Maximum occupancy (cap)", "pct", "%", 0, 100),
    ("tariff", "Tariff per room per day", "num", "Rs.", 0, None),
    ("tariff_inc", "Annual increase in room tariff", "pct", "%", -100, 1000),
]
S_EXP = [
    ("exp_fb", "Food & beverages consumables", "pct", "% of revenue", 0, 100),
    ("exp_emp", "Employee costs", "pct", "% of revenue", 0, 100),
    ("exp_power", "Power & fuel", "pct", "% of revenue", 0, 100),
    ("exp_oth", "Other variable expenses", "pct", "% of revenue", 0, 100),
    ("exp_service", "Service fees to Marriott", "pct", "% of room revenue", 0, 100),
    ("admin", "Administrative & selling expenses (year 1)", "pct", "% of revenue", 0, 100),
    ("admin_inc", "Annual increase in administrative expenses", "pct", "%", -100, 1000),
]
S_GENERAL = [
    ("start_fy", "First construction year starts in", "int", "(e.g. 2024 = FY 2024-25)", 1990, 2100),
]
S_REPAY = [
    ("tenure", "Term loan repayment tenure", "int", "years", 1, MAX_YEARS),
    ("installments", "Number of installments", "int", "equal installments over the tenure", 1, None),
]
ALL_SCALARS = S_GENERAL + S_FINANCE + S_DEPREC + S_MIX + S_OPER + S_EXP + S_REPAY


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def fy_label(y):
    return "%d-%02d" % (y, (y + 1) % 100)


def disp(v, pct=False):
    """Number -> clean text for an input box."""
    if pct:
        v = v * 100.0
    v = round(float(v), 6)
    s = ("%.6f" % v).rstrip("0").rstrip(".")
    return s if s not in ("", "-0") else "0"


def repayment_schedule(tenure, installments):
    """Number of installments falling in each year of the tenure.

    Installments are equal and spread evenly over the tenure: installment k falls due
    k * tenure / installments years after repayment starts and is booked in that year
    (12 installments over 3 years -> 4 a year;  5 over 10 years -> one every second year)."""
    counts = [0] * tenure
    for k in range(1, installments + 1):
        year = -((-k * tenure) // installments)      # ceil(k * tenure / installments), integer maths
        counts[year - 1] += 1
    return counts


def cell_fmt(v):
    """Rs. Crore figure for a calculated table cell ('-' for zero, like the Excel sheet)."""
    if v is None:
        return ""
    return "-" if abs(v) < 0.005 else "{:,.2f}".format(v)


def fmt_val(v, f):
    """Format a report value for display."""
    if v is None or v == "":
        return ""
    if isinstance(v, str):
        return v
    if f == "pct":
        return "%.2f%%" % (v * 100.0)
    if f == "x":
        return "%.2fx" % v
    if f == "num0":
        return "{:,.0f}".format(v)
    if f == "yrs":
        return "%.2f years" % v
    if f == "int":
        return str(int(v))
    if abs(v) < 0.005:
        v = 0.0
    return "{:,.2f}".format(v)


def irr(flows):
    """Internal rate of return by bisection (no external libraries)."""
    def npv(r):
        return sum(cf / ((1.0 + r) ** t) for t, cf in enumerate(flows))
    lo, hi = -0.99, 10.0
    flo, fhi = npv(lo), npv(hi)
    if flo * fhi > 0:
        return None
    for _ in range(300):
        mid = (lo + hi) / 2.0
        fm = npv(mid)
        if flo * fm <= 0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
    return (lo + hi) / 2.0


# --------------------------------------------------------------------------
# Calculation engine
# --------------------------------------------------------------------------
def compute(a):
    """All project-finance calculations. Returns a dictionary of results."""
    N = int(a["tenure"])                     # operating years = repayment tenure
    rate = a["rate"]
    items = a["items"]
    n = len(items)
    cost = [it["cost"] for it in items]
    margin = [it["margin"] for it in items]

    # ---- Construction period: nq quarters, grouped into financial years ---
    nq = int(a["quarters"])
    ny = (nq + 3) // 4                       # number of construction years

    def ysum(lst):                           # quarter list -> year totals
        return [sum(lst[4 * k:4 * k + 4]) for k in range(ny)]

    # ---- Cost phasing: quarters 1..nq-1 are inputs, the last is the balance ---
    phasing = []
    for it in items:
        ph = list(it["phasing"])[:nq - 1]
        ph += [0.0] * (nq - 1 - len(ph))
        phasing.append(ph + [1.0 - sum(ph)])
    cost_q = [[cost[i] * phasing[i][q] for q in range(nq)] for i in range(n)]
    prom_q = [[cost_q[i][q] * margin[i] for q in range(nq)] for i in range(n)]
    bank_q = [[cost_q[i][q] - prom_q[i][q] for q in range(nq)] for i in range(n)]
    tot_q = [sum(cost_q[i][q] for i in range(n)) for q in range(nq)]
    prom_tot_q = [sum(prom_q[i][q] for i in range(n)) for q in range(nq)]
    bank_tot_q = [sum(bank_q[i][q] for i in range(n)) for q in range(nq)]

    # ---- Term-loan draw-down and interest during construction ------------
    idc_q, opening = [], 0.0
    dd_open, dd_close, dd_avg = [], [], []
    for q in range(nq):
        closing = opening + bank_tot_q[q]
        dd_open.append(opening)
        dd_close.append(closing)
        dd_avg.append((opening + closing) / 2.0)
        idc_q.append(dd_avg[-1] * rate * 3.0 / 12.0)
        opening = closing
    idc = sum(idc_q)
    idc_y = ysum(idc_q)

    prom_item = [cost[i] * margin[i] for i in range(n)]
    bank_item = [cost[i] - prom_item[i] for i in range(n)]
    core = sum(cost)
    core_prom, core_bank = sum(prom_item), sum(bank_item)
    total_cost = core + idc
    total_prom = core_prom + idc            # IDC is funded 100 % by promoters
    total_bank = core_bank
    loan = total_bank

    cost_y = ysum(tot_q)
    out_y = [cost_y[k] + idc_y[k] for k in range(ny)]
    equity_y = [ysum(prom_tot_q)[k] + idc_y[k] for k in range(ny)]
    debt_y = ysum(bank_tot_q)

    # ---- Depreciation -----------------------------------------------------
    # Each item is capitalised to Building / Equipment / Land / a split of the two.
    # Interest during construction is shared 50:50 between building and equipment.
    b_direct = b_shared = e_direct = e_shared = 0.0
    for it in items:
        if it["cat"] == "building":
            b_direct += it["cost"]
        elif it["cat"] == "equipment":
            e_direct += it["cost"]
        elif it["cat"] == "shared":
            b_shared += it["cost"] * it["bshare"]
            e_shared += it["cost"] * (1.0 - it["bshare"])
        # "land" is never depreciated
    bldg_cost = b_direct + b_shared + idc / 2.0
    equip_cost = e_direct + e_shared + idc / 2.0
    main_tbl = [[b_direct, b_shared, idc / 2.0, bldg_cost],
                [e_direct, e_shared, idc / 2.0, equip_cost]]
    dep_b = bldg_cost / a["life_bldg"]
    dep_e = equip_cost / a["life_equip"]
    dep = dep_b + dep_e

    # ---- Operating years --------------------------------------------------
    occ, tariff = [], []
    for i in range(N):
        if i == 0:
            occ.append(a["occ"])
            tariff.append(a["tariff"])
        else:
            occ.append(min(a["occ_cap"], occ[-1] + a["occ_inc"]))
            tariff.append(tariff[-1] * (1.0 + a["tariff_inc"]))

    room = [a["rooms"] * a["days"] * occ[i] * tariff[i] / 1e7 for i in range(N)]
    fb = [r * a["fb_share"] / a["room_share"] for r in room]
    oth = [r * a["others_share"] / a["room_share"] for r in room]
    rev = [room[i] + fb[i] + oth[i] for i in range(N)]

    v_fb = [r * a["exp_fb"] for r in rev]
    v_emp = [r * a["exp_emp"] for r in rev]
    v_pow = [r * a["exp_power"] for r in rev]
    v_oth = [r * a["exp_oth"] for r in rev]
    v_srv = [r * a["exp_service"] for r in room]
    var_tot = [v_fb[i] + v_emp[i] + v_pow[i] + v_oth[i] + v_srv[i] for i in range(N)]

    admin = []
    for i in range(N):
        admin.append(rev[0] * a["admin"] if i == 0 else admin[-1] * (1.0 + a["admin_inc"]))

    # ---- Term-loan repayment schedule ------------------------------------
    inst_n = int(a["installments"])
    inst_y = repayment_schedule(N, inst_n)
    rep_pct = [c / float(inst_n) for c in inst_y]
    rep_pct[-1] = 1.0 - sum(rep_pct[:-1])
    l_open, l_rep, l_close, l_avg, l_int = [], [], [], [], []
    bal = loan
    for i in range(N):
        l_open.append(bal)
        rp = loan * rep_pct[i]
        l_rep.append(rp)
        bal = bal - rp
        l_close.append(bal)
        l_avg.append((l_open[i] + bal) / 2.0)
        l_int.append(l_avg[i] * rate)

    # straight-line depreciation; each asset stops depreciating when its useful life ends
    def life_frac(i, life):
        return max(0.0, min(1.0, life - i))
    depr = [dep_b * life_frac(i, a["life_bldg"]) + dep_e * life_frac(i, a["life_equip"]) for i in range(N)]
    fixed = [admin[i] + depr[i] + l_int[i] for i in range(N)]
    total_exp = [var_tot[i] + fixed[i] for i in range(N)]
    pbt = [rev[i] - total_exp[i] for i in range(N)]
    tax = [max(0.0, pbt[i] * a["tax"]) for i in range(N)]   # no negative tax on losses
    pat = [pbt[i] - tax[i] for i in range(N)]

    # ---- DSCR -------------------------------------------------------------
    cfads = [pat[i] + l_int[i] + depr[i] for i in range(N)]
    debt_service = [l_int[i] + l_rep[i] for i in range(N)]
    dscr = [cfads[i] / debt_service[i] if debt_service[i] > 1e-12 else None for i in range(N)]
    ds_sum = sum(debt_service)
    avg_dscr = sum(cfads) / ds_sum if ds_sum > 1e-12 else None
    valid = [d for d in dscr if d is not None]
    min_dscr = min(valid) if valid else None

    # ---- IRR / Payback ----------------------------------------------------
    terminal = total_cost - sum(depr)
    T = ny + N                               # total columns: construction + operating years
    irr_cf = [0.0] * T
    irr_tv = [0.0] * T
    irr_out = [0.0] * T
    for i in range(N):
        irr_cf[ny + i] = cfads[i]
    irr_tv[T - 1] = terminal
    for k in range(ny):
        irr_out[k] = -out_y[k]
    irr_tot = [irr_cf[i] + irr_tv[i] + irr_out[i] for i in range(T)]
    project_irr = irr(irr_tot)
    avg_cf = sum(cfads) / N
    payback = total_cost / avg_cf if avg_cf > 1e-12 else None

    # ---- Break-even -------------------------------------------------------
    contrib = [rev[i] - var_tot[i] for i in range(N)]
    pv = [contrib[i] / rev[i] if rev[i] > 1e-12 else 0.0 for i in range(N)]
    bep = [fixed[i] / pv[i] if pv[i] > 1e-12 else None for i in range(N)]
    bep_pct = [bep[i] / rev[i] if bep[i] is not None else None for i in range(N)]
    fixed_cash = [fixed[i] - depr[i] for i in range(N)]
    cbep = [fixed_cash[i] / pv[i] if pv[i] > 1e-12 else None for i in range(N)]
    cbep_pct = [cbep[i] / rev[i] if cbep[i] is not None else None for i in range(N)]

    # ---- Cash flow statement (construction years + 10 operating years) -----
    zc, z10 = [0.0] * ny, [0.0] * N
    cf_npat = zc + pat
    cf_dep = zc + depr
    cf_cap = list(equity_y) + z10
    cf_debt = list(debt_y) + z10
    cf_funds = [cf_npat[i] + cf_dep[i] + cf_cap[i] + cf_debt[i] for i in range(T)]
    cf_fa = list(out_y) + z10
    cf_rep = zc + l_rep
    cf_out = [cf_fa[i] + cf_rep[i] for i in range(T)]
    cf_surplus = [cf_funds[i] - cf_out[i] for i in range(T)]
    cf_open, cf_close, bal = [], [], 0.0
    for i in range(T):
        cf_open.append(bal)
        bal += cf_surplus[i]
        cf_close.append(bal)

    # ---- Balance sheet ----------------------------------------------------
    def running(lst):
        out, tot = [], 0.0
        for v in lst:
            tot += v
            out.append(tot)
        return out

    gross = zc + [total_cost] * N
    accdep = zc + running(depr)
    net = [gross[i] - accdep[i] for i in range(T)]
    cwip = running(out_y) + z10
    cash = cf_close
    assets = [net[i] + cwip[i] + cash[i] for i in range(T)]
    equity = running(equity_y)
    equity = equity + [equity[-1]] * N
    reserves = zc + running(pat)
    networth = [equity[i] + reserves[i] for i in range(T)]
    bank_loan = running(debt_y) + l_close
    liab = [networth[i] + bank_loan[i] for i in range(T)]
    diff = [liab[i] - assets[i] for i in range(T)]

    fy0 = a["start_fy"]
    con_years = [fy_label(fy0 + i) for i in range(ny)]
    ops_years = [fy_label(fy0 + ny + i) for i in range(N)]

    return dict(
        N=N, nq=nq, ny=ny, con_years=con_years, ops_years=ops_years, all_years=con_years + ops_years,
        cost_item=cost, prom_item=prom_item, bank_item=bank_item,
        core=core, core_prom=core_prom, core_bank=core_bank,
        idc=idc, total_cost=total_cost, total_prom=total_prom, total_bank=total_bank,
        loan=loan, out_y=out_y, dep=dep, dep_b=dep_b, dep_e=dep_e,
        cost_q=cost_q, prom_q=prom_q, bank_q=bank_q, tot_q=tot_q,
        prom_tot_q=prom_tot_q, bank_tot_q=bank_tot_q,
        dd_open=dd_open, dd_close=dd_close, dd_avg=dd_avg, idc_q=idc_q,
        cost_y=cost_y, idc_y=idc_y, main_tbl=main_tbl,
        occ=occ, tariff=tariff, room=room, fb=fb, oth=oth, rev=rev,
        v_fb=v_fb, v_emp=v_emp, v_pow=v_pow, v_oth=v_oth, v_srv=v_srv, var_tot=var_tot,
        admin=admin, depr=depr, l_int=l_int, fixed=fixed, total_exp=total_exp,
        pbt=pbt, tax=tax, pat=pat,
        rep_pct=rep_pct, inst_y=inst_y, inst_n=inst_n, l_open=l_open, l_rep=l_rep, l_close=l_close, l_avg=l_avg,
        cfads=cfads, debt_service=debt_service, dscr=dscr, avg_dscr=avg_dscr, min_dscr=min_dscr,
        irr_cf=irr_cf, irr_tv=irr_tv, irr_out=irr_out, irr_tot=irr_tot, irr=project_irr,
        avg_cf=avg_cf, payback=payback,
        contrib=contrib, pv=pv, bep=bep, bep_pct=bep_pct,
        fixed_cash=fixed_cash, cbep=cbep, cbep_pct=cbep_pct,
        cf_npat=cf_npat, cf_dep=cf_dep, cf_cap=cf_cap, cf_debt=cf_debt, cf_funds=cf_funds,
        cf_fa=cf_fa, cf_rep=cf_rep, cf_out=cf_out, cf_surplus=cf_surplus,
        cf_open=cf_open, cf_close=cf_close,
        gross=gross, accdep=accdep, net=net, cwip=cwip, cash=cash, assets=assets,
        equity=equity, reserves=reserves, networth=networth, bank_loan=bank_loan,
        liab=liab, diff=diff,
    )


def build_reports(a, R):
    """
    Turn results into report tables.
    Row = (kind, label, values, fmt); kind: head, section, row, total, grand, check, blank, note
    """
    N = R["N"]
    ops, allf = R["ops_years"], R["all_years"]
    NOTE = ("note", "All amounts in Rs. in Crores", [], "num")
    BL = ("blank", "", [], "num")

    def nn(lst):                       # None -> "n/a"
        return [("n/a" if v is None else v) for v in lst]

    # ------------------------- Project Income Statement -------------------
    IS = [
        ("head", "Particulars", ops, "num"),
        NOTE,
        ("row", "Occupancy Assumed", R["occ"], "pct"),
        ("row", "Room Tariff per day (Rs.)", R["tariff"], "num0"),
        ("section", "Total Revenues during the Year:", [], "num"),
        ("row", "Room revenues", R["room"], "num"),
        ("row", "Food & Beverages", R["fb"], "num"),
        ("row", "Other Sources", R["oth"], "num"),
        ("total", "Total Revenues during the Year [A]", R["rev"], "num"),
        ("section", "Total Expenditure for the Year:", [], "num"),
        ("section", "Variable Expenses:", [], "num"),
        ("row", "Food & Beverages Consumables", R["v_fb"], "num"),
        ("row", "Employee Costs", R["v_emp"], "num"),
        ("row", "Power & Fuel", R["v_pow"], "num"),
        ("row", "Other Variable Expenses", R["v_oth"], "num"),
        ("row", "Service Fees to Marriott [Room revenue]", R["v_srv"], "num"),
        ("total", "Total Variable Expenses [B]", R["var_tot"], "num"),
        ("section", "Fixed Expenses:", [], "num"),
        ("row", "Administrative & Selling Expenses", R["admin"], "num"),
        ("row", "Depreciation", R["depr"], "num"),
        ("row", "Interest on Term Loan", R["l_int"], "num"),
        ("total", "Total Fixed Expenses [C]", R["fixed"], "num"),
        ("total", "Total Expenditure for the Year [D=B+C]", R["total_exp"], "num"),
        ("total", "Net Profit Before Tax [E=A-D]", R["pbt"], "num"),
        ("row", "[-] Tax", R["tax"], "num"),
        ("grand", "Net Profit After Tax", R["pat"], "num"),
        BL,
        ("head", "Term Loan Repayment Schedule", ops, "num"),
        ("row", "Number of Installments in the Year", R["inst_y"], "int"),
        ("row", "Repayment for the Year in %age", R["rep_pct"], "pct"),
        ("row", "Opening Balance", R["l_open"], "num"),
        ("row", "[-] Repayment", R["l_rep"], "num"),
        ("row", "Closing Balance", R["l_close"], "num"),
        ("row", "Average Balance", R["l_avg"], "num"),
        ("total", "Interest on Term Loan", R["l_int"], "num"),
        BL,
        ("head", "Debt Service Coverage Ratio", ops, "num"),
        ("row", "Net Profit After tax", R["pat"], "num"),
        ("row", "[+] Interest Payment During the Year", R["l_int"], "num"),
        ("row", "[+] Depreciation for the year", R["depr"], "num"),
        ("total", "Total Cash-flow available for servicing the debt", R["cfads"], "num"),
        ("row", "Interest Payment During the Year", R["l_int"], "num"),
        ("row", "[+] Principal Repayment during the year", R["l_rep"], "num"),
        ("total", "Total Debt repayment during the Year", R["debt_service"], "num"),
        ("grand", "Debt Service Coverage Ratio [in times]", nn(R["dscr"]), "x"),
        ("grand", "Average DSCR [in times]",
         ["n/a" if R["avg_dscr"] is None else R["avg_dscr"]], "x"),
        BL,
        ("head", "Internal Rate of Return", allf, "num"),
        ("row", "Cash-Flow After Tax", R["irr_cf"], "num"),
        ("row", "[+] Terminal Value of Fixed Assets", R["irr_tv"], "num"),
        ("row", "Project Cash Outflow", R["irr_out"], "num"),
        ("total", "Total Cash-Flows", R["irr_tot"], "num"),
        ("grand", "Internal Rate of Return", ["n/a" if R["irr"] is None else R["irr"]], "pct"),
        BL,
        ("head", "Pay-Back Period", ops, "num"),
        ("row", "Total Cash-flow available for servicing the debt", R["cfads"], "num"),
        ("row", "Average Cash-Flows", [R["avg_cf"]], "num"),
        ("row", "Cost of Project", [R["total_cost"]], "num"),
        ("grand", "Simple Pay-Back Period",
         ["n/a" if R["payback"] is None else R["payback"]], "yrs"),
        BL,
        ("head", "Break-Even Point", ops, "num"),
        ("row", "Total Sales [A]", R["rev"], "num"),
        ("row", "[-] Variable Cost [B]", R["var_tot"], "num"),
        ("total", "Contribution [C=A-B]", R["contrib"], "num"),
        ("row", "Profit Volume Ratio [D=C/A]", R["pv"], "pct"),
        ("row", "Fixed Costs [E]", R["fixed"], "num"),
        ("row", "Net Profit Before Tax [F=C-E]", R["pbt"], "num"),
        ("total", "Break-Even Point [E/D]", nn(R["bep"]), "num"),
        ("row", "BEP as a %age of Sales", nn(R["bep_pct"]), "pct"),
        ("row", "Fixed Costs excluding Depreciation", R["fixed_cash"], "num"),
        ("total", "Cash-Break Even Point", nn(R["cbep"]), "num"),
        ("row", "Cash Break Even Point as %age of sales", nn(R["cbep_pct"]), "pct"),
    ]

    # ------------------------- Projected Balance Sheet --------------------
    BS = [
        ("head", "Particulars", allf, "num"),
        NOTE,
        ("section", "Assets:", [], "num"),
        ("row", "Gross Block", R["gross"], "num"),
        ("row", "[-] Accumulated Depreciation", R["accdep"], "num"),
        ("total", "Net Block", R["net"], "num"),
        ("row", "Capital Work in Progress", R["cwip"], "num"),
        ("row", "Cash & Bank Balance", R["cash"], "num"),
        ("grand", "Total Assets", R["assets"], "num"),
        ("section", "Liabilities:", [], "num"),
        ("row", "Core Equity Capital", R["equity"], "num"),
        ("row", "[+] Reserves & Surplus", R["reserves"], "num"),
        ("total", "Net Worth", R["networth"], "num"),
        ("row", "Bank Loan", R["bank_loan"], "num"),
        ("grand", "Total Liabilities", R["liab"], "num"),
        ("check", "Difference", R["diff"], "num"),
    ]

    # ------------------------- Projected Cash Flow Statement --------------
    CF = [
        ("head", "Particulars", allf, "num"),
        NOTE,
        ("section", "Sources of Finance:", [], "num"),
        ("row", "Net Profit After Tax", R["cf_npat"], "num"),
        ("row", "[+] Depreciation", R["cf_dep"], "num"),
        ("row", "[+] Capital Infusion", R["cf_cap"], "num"),
        ("row", "[+] Debt Capital Raised", R["cf_debt"], "num"),
        ("total", "Total Funds Infused [A]", R["cf_funds"], "num"),
        ("section", "Use of Funds:", [], "num"),
        ("row", "Fixed Assets Purchased", R["cf_fa"], "num"),
        ("row", "Term Loan Repaid", R["cf_rep"], "num"),
        ("total", "Total Out-Flow [B]", R["cf_out"], "num"),
        ("total", "Surplus [A-B]", R["cf_surplus"], "num"),
        ("row", "Opening Balance", R["cf_open"], "num"),
        ("grand", "Closing Balance", R["cf_close"], "num"),
    ]
    return IS, BS, CF


def assumption_rows(a, R):
    """Assumption summary used for the Excel export."""
    rows = [("head", "Assumption", ["Value"], "num")]
    rows += [
        ("section", "General", [], "num"),
        ("row", "Project name", [a["project_name"]], "text"),
        ("row", "First construction year", [fy_label(a["start_fy"])], "text"),
        ("section", "Total Project Cost (Rs. in Crores)", [], "num"),
        ("head", "Particulars", ["Total Cost", "Margin Requirement", "Promoter's Contribution",
                                   "Bank Finance", "Depreciation treatment"], "num"),
    ]
    for i, it in enumerate(a["items"]):
        treat = CAT_LABEL[it["cat"]]
        if it["cat"] == "shared":
            treat += " (%s%% building)" % disp(it["bshare"], True)
        rows.append(("row", it["name"], [it["cost"], it["margin"], R["prom_item"][i],
                                          R["bank_item"][i], treat],
                     ["num", "pct", "num", "num", "text"]))
    rows.append(("total", "Core Project Cost [A]", [R["core"], "", R["core_prom"], R["core_bank"]], "num"))
    rows.append(("row", "Interest During Construction [B]", [R["idc"], 1.0, R["idc"], 0.0],
                 ["num", "pct", "num", "num"]))
    rows.append(("grand", "Total Project Cost [A+B]", [R["total_cost"], "", R["total_prom"], R["total_bank"]], "num"))
    rows.append(("blank", "", [], "num"))
    rows.append(("head", "Cost Phasing in %age", ["Q%d" % (q + 1) for q in range(R["nq"])], "num"))
    for it in a["items"]:
        ph = list(it["phasing"])
        rows.append(("row", it["name"], ph[:R["nq"] - 1] + [1.0 - sum(ph[:R["nq"] - 1])], "pct"))
    rows.append(("section", "Finance, Tax & Depreciation", [], "num"))
    single = [
        ("Rate of interest on term loan", a["rate"], "pct"),
        ("Corporate income tax", a["tax"], "pct"),
        ("Useful life - hotel building (years)", a["life_bldg"], "num"),
        ("Useful life - kitchen equipment (years)", a["life_equip"], "num"),
        ("Proportion in revenue - Room", a["room_share"], "pct"),
        ("Proportion in revenue - Food & Beverage", a["fb_share"], "pct"),
        ("Proportion in revenue - Others", a["others_share"], "pct"),
        ("Total number of rooms", a["rooms"], "int"),
        ("Days rooms offered per year", a["days"], "int"),
        ("Occupancy - first year", a["occ"], "pct"),
        ("Yearly increase in occupancy", a["occ_inc"], "pct"),
        ("Maximum occupancy (cap)", a["occ_cap"], "pct"),
        ("Tariff per room per day (Rs.)", a["tariff"], "num0"),
        ("Annual increase in room tariff", a["tariff_inc"], "pct"),
        ("Food & beverages consumables (% of revenue)", a["exp_fb"], "pct"),
        ("Employee costs (% of revenue)", a["exp_emp"], "pct"),
        ("Power & fuel (% of revenue)", a["exp_power"], "pct"),
        ("Other variable expenses (% of revenue)", a["exp_oth"], "pct"),
        ("Service fees to Marriott (% of room revenue)", a["exp_service"], "pct"),
        ("Administrative & selling expenses (% of revenue, year 1)", a["admin"], "pct"),
        ("Annual increase in administrative expenses", a["admin_inc"], "pct"),
        ("Term loan repayment tenure (years)", a["tenure"], "int"),
        ("Number of installments (equal)", a["installments"], "int"),
    ]
    for lbl, v, f in single:
        rows.append(("row", lbl, [v], f))
    return rows


# --------------------------------------------------------------------------
# Simple canvas bar chart (no external libraries)
# --------------------------------------------------------------------------
def draw_bars(cv, title, labels, series, colors, names, hline=None, hname="", fmt="%.1f"):
    cv.delete("all")
    w, h = cv.winfo_width(), cv.winfo_height()
    if w < 150 or h < 120:
        return
    ml, mr, mt, mb = 52, 16, 46, 34
    pw, ph = w - ml - mr, h - mt - mb
    vals = [v for s in series for v in s if v is not None]
    if hline is not None:
        vals.append(hline)
    vmax, vmin = max(vals + [0.0]), min(vals + [0.0])
    if vmax - vmin < 1e-9:
        vmax = vmin + 1.0
    span = vmax - vmin

    def Y(v):
        return mt + (vmax - v) / span * ph

    cv.create_text(ml, 16, text=title, anchor="w", font=FONT_B, fill=PRIMARY)
    x = w - mr
    for nm, col in reversed(list(zip(names, colors))):
        x -= 9 * len(nm) + 26
        cv.create_rectangle(x, 30, x + 10, 40, fill=col, outline=col)
        cv.create_text(x + 14, 35, text=nm, anchor="w", font=FONT_S, fill="#444444")
    for k in range(5):
        v = vmin + span * k / 4.0
        y = Y(v)
        cv.create_line(ml, y, w - mr, y, fill="#E3DDF3")
        cv.create_text(ml - 6, y, text=fmt % v, anchor="e", font=("Segoe UI", 8), fill="#666666")
    n = len(labels)
    gw = pw / float(n)
    bw = gw * 0.72 / len(series)
    for i in range(n):
        gx = ml + i * gw + gw * 0.14
        for j, s in enumerate(series):
            v = s[i]
            if v is None:
                continue
            cv.create_rectangle(gx + j * bw, Y(max(v, 0)), gx + (j + 1) * bw - 1, Y(min(v, 0)),
                                fill=colors[j], outline="")
        cv.create_text(ml + i * gw + gw / 2, h - mb + 14, text=labels[i],
                       font=("Segoe UI", 8), fill="#444444")
    if hline is not None:
        y = Y(hline)
        cv.create_line(ml, y, w - mr, y, fill=RED, dash=(5, 3), width=2)
        cv.create_text(w - mr - 2, y - 8, text=hname, anchor="e", font=FONT_S, fill=RED)


# --------------------------------------------------------------------------
# The application window
# --------------------------------------------------------------------------
class App:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.configure(bg=BG)
        sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
        self.root.geometry("%dx%d+10+10" % (min(1320, sw - 40), min(800, sh - 80)))
        self.root.minsize(980, 620)
        self._loading = False
        self.a = None
        self.R = None
        self.reports = None

        # form variables
        self.v_name = tk.StringVar()
        self.v = {k[0]: tk.StringVar() for k in ALL_SCALARS}
        self.rows = []          # one entry per cost item (dynamic - add / remove / rename)
        self.nq = 8                 # construction period in quarters (dynamic)
        self.tenure_var = tk.StringVar()
        self.static_updaters = []   # functions(R) that refresh fixed calculated tables
        self.dyn_updaters = []      # functions(R) for tables that follow the cost-item list
        self.fy_static, self.fy_dyn = [], []    # financial-year header labels
        self.dep_vars = {k: tk.StringVar() for k in ("b", "e", "t")}
        self.mix_total = tk.StringVar(value="100")
        self.repay_info = tk.StringVar()    # "Repayment tenure: 10 years (2026-27 to 2035-36)"
        self.inst_info = tk.StringVar()     # frequency and size of each installment
        self._loan_cache = None             # last computed term loan (for the installment amount)
        self.others_var = tk.StringVar()
        self.d_tot = {k: tk.StringVar() for k in
                      ("core_c", "core_p", "core_b", "idc_c", "idc_p", "idc_b",
                       "tot_c", "tot_p", "tot_b")}

        self._setup_style()
        self._build_header()
        self._build_toolbar()
        self._build_status()
        self._build_tabs()

        self._load_into_form(DEFAULTS)
        self._hook_traces()
        self._refresh_derived()
        self.generate_report(silent=True)

    # ------------------------------------------------------------------ style
    def _setup_style(self):
        s = ttk.Style()
        try:
            s.theme_use("clam")
        except tk.TclError:
            pass
        s.configure("TNotebook", background=BG, borderwidth=0)
        s.configure("TNotebook.Tab", padding=(20, 9), font=FONT_B,
                    background="#D1C4E9", foreground=PRIMARY)
        s.map("TNotebook.Tab",
              background=[("selected", PRIMARY), ("active", "#B39DDB")],
              foreground=[("selected", "white")])
        s.configure("Treeview", rowheight=25, font=FONT, background="white",
                    fieldbackground="white", borderwidth=0)
        s.configure("Treeview.Heading", font=FONT_B, background=PRIMARY,
                    foreground="white", relief="flat", padding=6)
        s.map("Treeview.Heading", background=[("active", ORANGE)])
        s.map("Treeview", background=[("selected", "#7E57C2")],
              foreground=[("selected", "white")])

    # ----------------------------------------------------------------- header
    def _build_header(self):
        head = tk.Frame(self.root, bg=PRIMARY)
        head.pack(fill="x")
        tk.Label(head, text=APP_TITLE, bg=PRIMARY, fg="white", font=FONT_T,
                 padx=18, pady=8).pack(side="left")
        tk.Label(head, text="Term Loan  |  Project Finance Model  |  Amounts in Rs. Crores",
                 bg=PRIMARY, fg="#D1C4E9", font=FONT).pack(side="left", padx=8)
        stripe = tk.Frame(self.root, height=5)
        stripe.pack(fill="x")
        for col in (ORANGE, PINK, TEAL, BLUE, GREEN, YELLOW):
            tk.Frame(stripe, bg=col, height=5).pack(side="left", fill="x", expand=True)

    def _build_toolbar(self):
        bar = tk.Frame(self.root, bg=BG, pady=8, padx=10)
        bar.pack(fill="x")
        buttons = [
            ("\u25B6  Generate Report", GREEN, self.generate_report),
            ("Reset Defaults", ORANGE, self.reset_defaults),
            ("Save Assumptions", TEAL, self.save_assumptions),
            ("Load Assumptions", BLUE, self.load_assumptions),
            ("Export to Excel", PINK, self.export_excel),
        ]
        for text, col, cmd in buttons:
            b = tk.Button(bar, text=text, command=cmd, bg=col, fg="white", font=FONT_B,
                          relief="flat", bd=0, padx=16, pady=7, cursor="hand2",
                          activebackground=PRIMARY_D, activeforeground="white")
            b.pack(side="left", padx=(0, 8))
        tk.Label(bar, text="Project:", bg=BG, fg=PRIMARY, font=FONT_B).pack(side="left", padx=(24, 4))
        tk.Entry(bar, textvariable=self.v_name, width=30, font=FONT, relief="solid", bd=1).pack(side="left")

    def _build_status(self):
        self.status = tk.StringVar(value="Ready")
        self.status_lbl = tk.Label(self.root, textvariable=self.status, anchor="w", bg=PRIMARY_D,
                                   fg="white", font=FONT_S, padx=12, pady=4)
        self.status_lbl.pack(side="bottom", fill="x")

    # ------------------------------------------------------------------- tabs
    def _build_tabs(self):
        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=10, pady=(0, 8))

        self.tab_assump = tk.Frame(self.nb, bg=BG)
        self.tab_dash = tk.Frame(self.nb, bg=BG)
        self.nb.add(self.tab_assump, text="  Assumptions  ")
        self.nb.add(self.tab_dash, text="  Dashboard  ")
        self.tv_is = self._make_report_tab("  Project Income Statement  ",
                                           "Project Income Statement", PINK)
        self.tv_bs = self._make_report_tab("  Projected Balance Sheet  ",
                                           "Projected Balance Sheet", TEAL)
        self.tv_cf = self._make_report_tab("  Projected Cash Flow Statement  ",
                                           "Projected Cash Flow Statement", BLUE)
        self._build_assumption_tab()
        self._build_dashboard_tab()

    def _make_report_tab(self, tab_text, title, colour):
        frame = tk.Frame(self.nb, bg=BG)
        self.nb.add(frame, text=tab_text)
        tk.Label(frame, text=title + "   (Rs. in Crores)", bg=colour, fg="white",
                 font=FONT_H, anchor="w", padx=12, pady=6).pack(fill="x")
        holder = tk.Frame(frame, bg=BG)
        holder.pack(fill="both", expand=True)
        tv = ttk.Treeview(holder, show="headings", selectmode="browse")
        ysb = ttk.Scrollbar(holder, orient="vertical", command=tv.yview)
        xsb = ttk.Scrollbar(holder, orient="horizontal", command=tv.xview)
        tv.configure(yscrollcommand=ysb.set, xscrollcommand=xsb.set)
        holder.rowconfigure(0, weight=1)
        holder.columnconfigure(0, weight=1)
        tv.grid(row=0, column=0, sticky="nsew")
        ysb.grid(row=0, column=1, sticky="ns")
        xsb.grid(row=1, column=0, sticky="ew")
        tv.tag_configure("head", background=TEAL, foreground="white", font=FONT_B)
        tv.tag_configure("section", background="#EDE7F6", foreground=PRIMARY, font=FONT_B)
        tv.tag_configure("total", background="#FFF3C4", font=FONT_B)
        tv.tag_configure("grand", background="#C8E6C9", font=FONT_B)
        tv.tag_configure("odd", background="#FFFFFF")
        tv.tag_configure("even", background="#F7F3FF")
        tv.tag_configure("blank", background="#FFFFFF")
        tv.tag_configure("ok", background="#C8E6C9", foreground="#1B5E20", font=FONT_B)
        tv.tag_configure("bad", background="#FFCDD2", foreground="#B71C1C", font=FONT_B)
        tv.tag_configure("note", foreground="#777777", background="#FFFFFF")
        return tv

    # ------------------------------------------------------ assumption widgets
    def _entry(self, parent, var, width=10, readonly=False, justify="right"):
        e = tk.Entry(parent, textvariable=var, width=width, justify=justify, font=FONT,
                     relief="solid", bd=1, highlightthickness=1,
                     highlightbackground="#B39DDB", highlightcolor=ORANGE)
        if readonly:
            e.configure(state="readonly", readonlybackground="#E8F5E9", fg="#1B5E20")
        return e

    def _section(self, parent, title, colour):
        outer = tk.Frame(parent, bg=colour)
        tk.Label(outer, text=title, bg=colour, fg="white", font=FONT_H, anchor="w",
                 padx=10, pady=4).pack(fill="x")
        body = tk.Frame(outer, bg=CARD, padx=12, pady=10)
        body.pack(fill="both", expand=True, padx=2, pady=(0, 2))
        return outer, body

    def _scalar_rows(self, body, specs, start=0):
        body.columnconfigure(0, minsize=430)
        r = start
        for key, label, kind, unit, lo, hi in specs:
            tk.Label(body, text=label, bg=CARD, font=FONT, anchor="w").grid(row=r, column=0, sticky="w", pady=3)
            self._entry(body, self.v[key], 11).grid(row=r, column=1, padx=8, pady=3)
            tk.Label(body, text=unit, bg=CARD, fg="#777777", font=FONT_S).grid(row=r, column=2, sticky="w")
            r += 1
        return r

    def _build_assumption_tab(self):
        canvas = tk.Canvas(self.tab_assump, bg=BG, highlightthickness=0)
        vsb = ttk.Scrollbar(self.tab_assump, orient="vertical", command=canvas.yview)
        hsb = ttk.Scrollbar(self.tab_assump, orient="horizontal", command=canvas.xview)
        canvas.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        hsb.pack(side="bottom", fill="x")
        vsb.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        page = tk.Frame(canvas, bg=BG)
        win = canvas.create_window((0, 0), window=page, anchor="nw")

        def _fit(_e=None):
            # the page is at least as wide as the window; longer tenures (wider tables) scroll sideways
            canvas.itemconfigure(win, width=max(canvas.winfo_width(), page.winfo_reqwidth()))
            canvas.configure(scrollregion=canvas.bbox("all"))

        page.bind("<Configure>", _fit)
        canvas.bind("<Configure>", _fit)

        def _wheel(e):
            if e.num == 4:
                canvas.yview_scroll(-2, "units")
            elif e.num == 5:
                canvas.yview_scroll(2, "units")
            else:
                canvas.yview_scroll(int(-e.delta / 120) * 2 if e.delta else 0, "units")

        def _bind(_e):
            canvas.bind_all("<MouseWheel>", _wheel)
            canvas.bind_all("<Button-4>", _wheel)
            canvas.bind_all("<Button-5>", _wheel)

        def _unbind(_e):
            canvas.unbind_all("<MouseWheel>")
            canvas.unbind_all("<Button-4>")
            canvas.unbind_all("<Button-5>")

        canvas.bind("<Enter>", _bind)
        canvas.bind("<Leave>", _unbind)

        page.columnconfigure(0, weight=1)
        self.page = page
        tk.Label(page, text="The sections below follow the same order as the Excel 'Assumption Sheet'. "
                            "Type into the white boxes (percentages as numbers: 65 = 65 %). "
                            "Green boxes are calculated automatically. Cost items can be renamed, "
                            "added (+) or removed (x). Then press  \u25B6 Generate Report.",
                 bg=BG, fg=PRIMARY, font=FONT, anchor="w", wraplength=1100, justify="left"
                 ).grid(row=0, column=0, sticky="w", padx=10, pady=(8, 2))
        self._pr = 1                       # next free row on the page
        SP = {sp[0]: sp for sp in ALL_SCALARS}

        b = self._new_section("Project Timeline", "#5E35B1")
        self._scalar_rows(b, [SP["start_fy"]])

        # --- same sequence as the Excel Assumption Sheet ---------------------------
        self.cost_body = self._new_section(
            "Total Project Cost   (Amount in Rs. in Crores / Proportion in %age)", PRIMARY)
        self.phase_body = self._new_section("Cost Phasing in %age", TEAL)
        self.incurred_body = self._new_section("Cost Incurred in Rs.   (calculated)", ORANGE)
        self.alloc_body = self._new_section(
            "Term Loan Draw-Down & Promoters Margin requirement   (calculated)", PINK)
        self.dd_body = self._new_section("Term Loan Draw-Down Schedule   (calculated)", BLUE)
        self._build_main_item_section()
        self._build_depreciation_section()

        b = self._new_section("Proportion in Revenue Stream", "#00897B")
        r = self._scalar_rows(b, [SP["room_share"], SP["fb_share"]])
        tk.Label(b, text="Others (balance)", bg=CARD, font=FONT, anchor="w").grid(row=r, column=0, sticky="w", pady=3)
        self._entry(b, self.others_var, 11, True).grid(row=r, column=1, padx=8)
        tk.Label(b, text="% of total", bg=CARD, fg="#777777", font=FONT_S).grid(row=r, column=2, sticky="w")
        tk.Label(b, text="Total", bg=CARD, font=FONT_B, anchor="w").grid(row=r + 1, column=0, sticky="w", pady=3)
        self._entry(b, self.mix_total, 11, True).grid(row=r + 1, column=1, padx=8)
        tk.Label(b, text="% of total", bg=CARD, fg="#777777", font=FONT_S).grid(row=r + 1, column=2, sticky="w")

        b = self._new_section("Rooms, Occupancy & Tariff", "#F4511E")
        self._scalar_rows(b, [SP[k] for k in ("rooms", "days", "occ", "occ_inc", "tariff", "tariff_inc", "occ_cap")])

        b = self._new_section("Composition of Expenses", BLUE)
        self._scalar_rows(b, [SP[k] for k in ("exp_fb", "exp_emp", "exp_power", "exp_oth", "exp_service")])

        b = self._new_section("Fixed Expenses", "#8E24AA")
        self._scalar_rows(b, [SP["admin"], SP["admin_inc"]])

        b = self._new_section("Corporate Income Tax", "#546E7A")
        self._scalar_rows(b, [SP["tax"]])

        self.cashout_body = self._new_section("Total Cash Out-Flow   (calculated, Rs. in Crores)", "#00838F")

        b = self._new_section("Term Loan Repayment", GREEN)
        r = self._scalar_rows(b, [SP["tenure"], SP["installments"]])
        tk.Label(b, textvariable=self.repay_info, bg=CARD, fg=PRIMARY, font=FONT_B, anchor="w").grid(
            row=r, column=0, columnspan=3, sticky="w", pady=(10, 1))
        tk.Label(b, textvariable=self.inst_info, bg=CARD, fg=PRIMARY, font=FONT_B, anchor="w").grid(
            row=r + 1, column=0, columnspan=3, sticky="w", pady=1)
        tk.Label(b, text="Enter the tenure and the number of equal installments; the repayment schedule (installments, "
                         "opening balance, repayment, closing balance, interest) is generated in the Project Income "
                         "Statement tab. Repayment starts in the first operating year and the projections run for the "
                         "same number of years as the tenure. Maximum 12 installments a year (monthly).",
                 bg=CARD, fg="#777777", font=FONT_S, anchor="w", justify="left", wraplength=1050).grid(
            row=r + 2, column=0, columnspan=3, sticky="w", pady=(4, 0))
        tk.Label(page, text="", bg=BG).grid(row=self._pr, column=0, pady=6)

    # ----------------------------------------------- assumption-page building blocks
    def _new_section(self, title, colour):
        o, b = self._section(self.page, title, colour)
        o.grid(row=self._pr, column=0, sticky="ew", padx=8, pady=6)
        self._pr += 1
        return b

    def _calc_cell(self, parent, var, row, col, bold=False, bg="#F1F8E9", width=9):
        tk.Label(parent, textvariable=var, anchor="e", width=width, font=FONT_B if bold else FONT,
                 bg=bg, fg="#1B5E20", relief="solid", bd=1, padx=4).grid(
            row=row, column=col, padx=1, pady=1, sticky="ew")

    def _qheader(self, b, fy_list, total=True):
        """Particulars | FY1 (Q I-IV) | FY2 ... | Total header for self.nq quarters."""
        nq = self.nq
        hb, hf = "#B2DFDB", "#004D40"
        b.columnconfigure(0, weight=1)
        tk.Label(b, text="Particulars", bg=hb, fg=hf, font=FONT_B).grid(
            row=0, column=0, rowspan=2, sticky="nsew", padx=1, pady=1)
        for k in range((nq + 3) // 4):
            span = min(4, nq - 4 * k)
            lab = tk.Label(b, text="", bg=hb, fg=hf, font=FONT_B)
            lab.grid(row=0, column=1 + 4 * k, columnspan=span, sticky="ew", padx=1, pady=1)
            fy_list.append((lab, k))
        for q in range(nq):
            tk.Label(b, text="Q " + ["I", "II", "III", "IV"][q % 4], bg="#E0F2F1", fg=hf,
                     font=FONT_B).grid(row=1, column=q + 1, sticky="ew", padx=1, pady=1)
        if total:
            tk.Label(b, text="Total", bg=hb, fg=hf, font=FONT_B).grid(
                row=0, column=nq + 1, rowspan=2, sticky="nsew", padx=1, pady=1)
        return 2

    def _q_row(self, b, r, label, fn, fn_total, updaters, bold=False, label_var=None, indent=False):
        """One calculated row over the quarters.  fn(R, q) -> value ; fn_total(R) -> value or None."""
        nq = self.nq
        bg = "#FFF3C4" if bold else CARD
        pad = "      " if indent else ""
        if label_var is not None:
            tk.Label(b, textvariable=label_var, bg=bg, font=FONT_B if bold else FONT, anchor="w").grid(
                row=r, column=0, sticky="ew", pady=1)
        else:
            tk.Label(b, text=pad + label, bg=bg, font=FONT_B if bold else FONT, anchor="w").grid(
                row=r, column=0, sticky="ew", pady=1)
        cellbg = "#FFF3C4" if bold else "#F1F8E9"
        for q in range(nq):
            var = tk.StringVar()
            self._calc_cell(b, var, r, q + 1, bold, cellbg)
            updaters.append(lambda R, var=var, q=q: var.set(cell_fmt(fn(R, q))))
        if fn_total is not None:
            var = tk.StringVar()
            self._calc_cell(b, var, r, nq + 1, True, "#FFF3C4")
            updaters.append(lambda R, var=var: var.set(cell_fmt(fn_total(R))))

    def _build_drawdown_section(self):
        b = self.dd_body
        self._clear(b)
        r = self._qheader(b, self.fy_dyn)
        U = self.dyn_updaters
        self._q_row(b, r, "Opening Balance", lambda R, q: R["dd_open"][q], lambda R: R["dd_open"][0], U)
        self._q_row(b, r + 1, "[+] Draw Down", lambda R, q: R["bank_tot_q"][q],
                    lambda R: sum(R["bank_tot_q"]), U)
        self._q_row(b, r + 2, "Closing Balance", lambda R, q: R["dd_close"][q],
                    lambda R: R["dd_close"][-1], U, bold=True)
        self._q_row(b, r + 3, "Average Balance", lambda R, q: R["dd_avg"][q], None, U)
        self._q_row(b, r + 4, "Interest During Construction", lambda R, q: R["idc_q"][q],
                    lambda R: sum(R["idc_q"]), U, bold=True)
        rr = r + 5
        tk.Label(b, text="Rate of Interest in Term Loan", bg=CARD, font=FONT_B, anchor="w").grid(
            row=rr, column=0, sticky="w", pady=(12, 2))
        self._entry(b, self.v["rate"], 9).grid(row=rr, column=1, columnspan=2, sticky="w", padx=6, pady=(12, 2))
        tk.Label(b, text="% p.a.", bg=CARD, fg="#777777", font=FONT_S).grid(
            row=rr, column=3, sticky="w", pady=(12, 2))

    def _build_main_item_section(self):
        b = self._new_section("Name of the Main Item of the Project Cost   (calculated, Rs. in Crores)", "#3949AB")
        b.columnconfigure(0, weight=1)
        heads = ["Name of the Main Item of the Project Cost", "Base Cost", "Shared Items", "IDC", "Total Cost"]
        for c, t in enumerate(heads):
            tk.Label(b, text=t, bg="#C5CAE9", fg="#1A237E", font=FONT_B, padx=6, pady=3).grid(
                row=0, column=c, sticky="ew", padx=1, pady=1)
        names = ["Cost of Hotel Building", "Cost of Kitchen Equipment & Machinery"]
        for k, nm in enumerate(names):
            tk.Label(b, text=nm, bg=CARD, font=FONT, anchor="w").grid(row=k + 1, column=0, sticky="ew", pady=1)
            for c in range(4):
                var = tk.StringVar()
                self._calc_cell(b, var, k + 1, c + 1, c == 3, "#FFF3C4" if c == 3 else "#F1F8E9")
                self.static_updaters.append(lambda R, var=var, k=k, c=c: var.set(cell_fmt(R["main_tbl"][k][c])))
        tk.Label(b, text="Total Cost", bg="#FFF3C4", font=FONT_B, anchor="w").grid(row=3, column=0, sticky="ew", pady=1)
        for c in range(4):
            var = tk.StringVar()
            self._calc_cell(b, var, 3, c + 1, True, "#FFF3C4")
            self.static_updaters.append(
                lambda R, var=var, c=c: var.set(cell_fmt(R["main_tbl"][0][c] + R["main_tbl"][1][c])))
        tk.Label(b, text="Base Cost = items whose treatment is this asset class; Shared Items = the share of "
                         "'Shared' items; IDC is split 50:50.  Land is not depreciated and is not shown.",
                 bg=CARD, fg="#777777", font=FONT_S, anchor="w").grid(row=4, column=0, columnspan=5, sticky="w")

    def _build_depreciation_section(self):
        b = self._new_section("Useful Life Assumed for Charging Depreciation", ORANGE)
        b.columnconfigure(0, weight=1)
        for c, t in ((1, "Useful Life (years)"), (2, "Depreciation Per Year")):
            tk.Label(b, text=t, bg="#FFE0B2", fg="#E65100", font=FONT_B, padx=8, pady=3).grid(
                row=0, column=c, sticky="ew", padx=1, pady=1)
        tk.Label(b, text="", bg="#FFE0B2").grid(row=0, column=0, sticky="ew")
        for k, (label, key, dk) in enumerate((("Hotel Building", "life_bldg", "b"),
                                              ("Kitchen Equipment & Machinery", "life_equip", "e"))):
            tk.Label(b, text=label, bg=CARD, font=FONT, anchor="w").grid(row=k + 1, column=0, sticky="w", pady=3)
            self._entry(b, self.v[key], 10).grid(row=k + 1, column=1, padx=6)
            self._calc_cell(b, self.dep_vars[dk], k + 1, 2)
        tk.Label(b, text="Total Depreciation Per Year", bg="#FFF3C4", font=FONT_B, anchor="w").grid(
            row=3, column=0, sticky="ew", pady=2)
        self._calc_cell(b, self.dep_vars["t"], 3, 2, True, "#FFF3C4")
        # depreciation treatment of every cost item (filled by _build_dep_items)
        self.dep_items = tk.Frame(b, bg=CARD)
        self.dep_items.grid(row=4, column=0, columnspan=3, sticky="ew", pady=(14, 0))
        self.static_updaters.append(lambda R: (self.dep_vars["b"].set(cell_fmt(R["dep_b"])),
                                               self.dep_vars["e"].set(cell_fmt(R["dep_e"])),
                                               self.dep_vars["t"].set(cell_fmt(R["dep"]))))

    def _build_cashout_section(self):
        b = self.cashout_body
        self._clear(b)
        ny = (self.nq + 3) // 4
        b.columnconfigure(0, weight=1)
        hb, hf = "#B2DFDB", "#004D40"
        tk.Label(b, text="Total Cash Out-Flow", bg=hb, fg=hf, font=FONT_B).grid(
            row=0, column=0, sticky="nsew", padx=1, pady=1)
        for k in range(ny):
            lab = tk.Label(b, text="", bg=hb, fg=hf, font=FONT_B)
            lab.grid(row=0, column=k + 1, sticky="ew", padx=1, pady=1)
            self.fy_dyn.append((lab, k))
        tk.Label(b, text="Total", bg=hb, fg=hf, font=FONT_B).grid(row=0, column=ny + 1, sticky="ew", padx=1, pady=1)
        lines = (("Total Cost incurred in Rs. in Crores", "cost_y", False),
                 ("Interest During Construction in Rs. in Crores", "idc_y", False),
                 ("Total Cost incurred during the year in Rs. in Crores", "out_y", True))
        for k, (label, key, bold) in enumerate(lines):
            bg = "#FFF3C4" if bold else CARD
            tk.Label(b, text=label, bg=bg, font=FONT_B if bold else FONT, anchor="w").grid(
                row=k + 1, column=0, sticky="ew", pady=1)
            for c in range(ny + 1):
                var = tk.StringVar()
                self._calc_cell(b, var, k + 1, c + 1, bold or c == ny, "#FFF3C4" if bold else "#F1F8E9")
                if c < ny:
                    self.dyn_updaters.append(lambda R, var=var, key=key, c=c: var.set(cell_fmt(R[key][c])))
                else:
                    self.dyn_updaters.append(lambda R, var=var, key=key: var.set(cell_fmt(sum(R[key]))))

    def _build_dashboard_tab(self):
        f = self.tab_dash
        tk.Label(f, text="Project Snapshot", bg=BG, fg=PRIMARY, font=("Segoe UI", 15, "bold"),
                 anchor="w").pack(fill="x", padx=12, pady=(8, 2))
        self.cards_frame = tk.Frame(f, bg=BG)
        self.cards_frame.pack(fill="x", padx=8)
        self.card_vars = {}
        specs = [
            ("tot", "Total Project Cost", PRIMARY), ("prom", "Promoters' Contribution", TEAL),
            ("loan", "Term Loan (Bank Finance)", BLUE), ("idc", "Interest During Construction", ORANGE),
            ("de", "Debt : Equity (Loan / Promoter)", PINK),
            ("avg", "Average DSCR", GREEN), ("min", "Minimum DSCR", "#8E24AA"),
            ("irr", "Project IRR", "#F4511E"), ("pb", "Simple Pay-back", "#00ACC1"),
            ("bep", "Break-even (Year 1, % of sales)", "#3949AB"),
        ]
        for idx, (k, cap, col) in enumerate(specs):
            card = tk.Frame(self.cards_frame, bg=col, padx=10, pady=8)
            card.grid(row=idx // 5, column=idx % 5, sticky="nsew", padx=5, pady=5)
            self.cards_frame.columnconfigure(idx % 5, weight=1, uniform="cards")
            var = tk.StringVar(value="-")
            self.card_vars[k] = var
            tk.Label(card, textvariable=var, bg=col, fg="white", font=("Segoe UI", 19, "bold")).pack(anchor="w")
            tk.Label(card, text=cap, bg=col, fg="white", font=FONT_S).pack(anchor="w")

        mid = tk.Frame(f, bg=BG)
        mid.pack(fill="both", expand=True, padx=8, pady=4)
        mid.columnconfigure(0, weight=1, uniform="ch")
        mid.columnconfigure(1, weight=1, uniform="ch")
        mid.rowconfigure(0, weight=1)
        self.chart1 = tk.Canvas(mid, bg="white", highlightthickness=1, highlightbackground="#B39DDB")
        self.chart2 = tk.Canvas(mid, bg="white", highlightthickness=1, highlightbackground="#B39DDB")
        self.chart1.grid(row=0, column=0, sticky="nsew", padx=5, pady=4)
        self.chart2.grid(row=0, column=1, sticky="nsew", padx=5, pady=4)
        self.chart1.bind("<Configure>", lambda e: self._draw_charts())
        self.chart2.bind("<Configure>", lambda e: self._draw_charts())

        self.checks_frame = tk.Frame(f, bg=BG)
        self.checks_frame.pack(fill="x", padx=8, pady=(0, 8))

    def _draw_charts(self):
        if not self.R:
            return
        R = self.R
        lab = [y[2:] for y in R["ops_years"]]
        draw_bars(self.chart1, "Revenue vs Net Profit After Tax (Rs. Cr)", lab,
                  [R["rev"], R["pat"]], [BLUE, ORANGE], ["Revenue", "PAT"])
        d = [(0.0 if v is None else v) for v in R["dscr"]]
        draw_bars(self.chart2, "Debt Service Coverage Ratio (times)", lab, [d], [GREEN], ["DSCR"],
                  hline=1.25, hname="1.25x benchmark", fmt="%.2f")

    def _update_dashboard(self):
        R, a = self.R, self.a
        cv = self.card_vars
        cv["tot"].set("%.2f" % R["total_cost"])
        cv["prom"].set("%.2f" % R["total_prom"])
        cv["loan"].set("%.2f" % R["loan"])
        cv["idc"].set("%.2f" % R["idc"])
        cv["de"].set("%.2fx" % (R["loan"] / R["total_prom"]) if R["total_prom"] > 0 else "n/a")
        cv["avg"].set("n/a" if R["avg_dscr"] is None else "%.2fx" % R["avg_dscr"])
        cv["min"].set("n/a" if R["min_dscr"] is None else "%.2fx" % R["min_dscr"])
        cv["irr"].set("n/a" if R["irr"] is None else "%.2f%%" % (R["irr"] * 100))
        cv["pb"].set("n/a" if R["payback"] is None else "%.2f yrs" % R["payback"])
        b0 = R["bep_pct"][0]
        cv["bep"].set("n/a" if b0 is None else "%.1f%%" % (b0 * 100))

        for w in self.checks_frame.winfo_children():
            w.destroy()
        tk.Label(self.checks_frame, text="Banker's checks (indicative benchmarks):", bg=BG, fg=PRIMARY,
                 font=FONT_B).pack(side="left", padx=(4, 10))
        de = R["loan"] / R["total_prom"] if R["total_prom"] > 0 else None
        checks = [
            ("Min DSCR \u2265 1.25x", R["min_dscr"] is not None and R["min_dscr"] >= 1.25),
            ("IRR > loan interest rate", R["irr"] is not None and R["irr"] > a["rate"]),
            ("Debt : Equity \u2264 2 : 1", de is not None and de <= 2.0),
            ("Balance sheet tallies", max(abs(x) for x in R["diff"]) < 1e-6),
        ]
        for txt, ok in checks:
            tk.Label(self.checks_frame, text=("PASS  " if ok else "REVIEW  ") + txt,
                     bg=GREEN if ok else RED, fg="white", font=FONT_S, padx=8, pady=3).pack(side="left", padx=4)
        self._draw_charts()

    # ------------------------------------------------------- dynamic cost items
    def _make_row(self, it):
        """Create the StringVars for one cost item and attach live-update traces."""
        r = {
            "name": tk.StringVar(value=it["name"]),
            "cost": tk.StringVar(value=disp(it["cost"])),
            "margin": tk.StringVar(value=disp(it["margin"], True)),
            "cat": tk.StringVar(value=CAT_LABEL.get(it["cat"], CATS[1][1])),
            "bshare": tk.StringVar(value=disp(it["bshare"], True)),
            "phase": [tk.StringVar(value=disp(x, True)) for x in it["phasing"]],
            "phase_last": tk.StringVar(),
            "prom": tk.StringVar(),
            "bank": tk.StringVar(),
        }
        for var in [r["name"], r["cost"], r["margin"], r["cat"], r["bshare"]] + r["phase"]:
            var.trace_add("write", self._refresh_derived)
        r["cat"].trace_add("write", lambda *_a, row=r: self._sync_bshare(row))
        return r

    def _sync_bshare(self, r):
        """Building-share box is only used by the 'Shared' treatment."""
        e = r.get("bshare_entry")
        if e is None:
            return
        try:
            if r["cat"].get() == CATS[3][1]:
                e.configure(state="normal")
            else:
                e.configure(state="disabled", disabledbackground="#EEEEEE")
        except tk.TclError:
            pass

    def _clear(self, body):
        for w in body.winfo_children():
            w.destroy()

    def _rebuild_items(self):
        """(Re)draw every table that has one row per cost item."""
        self.dyn_updaters = []
        self.fy_dyn = []
        self._build_cost_section()
        self._build_dep_items()
        self._build_phasing_section()
        self._build_incurred_section()
        self._build_alloc_section()
        self._build_drawdown_section()
        self._build_cashout_section()
        self._update_fy_labels()

    def _build_cost_section(self):
        b = self.cost_body
        self._clear(b)
        heads = ["Particulars (editable)", "Total Cost", "Margin Requirement (%)",
                 "Promoter's Contribution", "Bank Finance"]
        for c, t in enumerate(heads):
            tk.Label(b, text=t, bg="#EDE7F6", fg=PRIMARY, font=FONT_B, padx=6, pady=4).grid(
                row=0, column=c, sticky="ew", padx=1, pady=1)
        b.columnconfigure(0, weight=1)
        n = len(self.rows)
        for i, r in enumerate(self.rows):
            g = i + 1
            # name box with the remove button placed right after it (same Particulars cell)
            cell = tk.Frame(b, bg=CARD)
            cell.grid(row=g, column=0, sticky="ew", padx=(0, 6), pady=3)
            tk.Button(cell, text="\u2716", command=lambda idx=i: self.remove_item(idx), bg=RED, fg="white",
                      font=FONT_B, relief="flat", bd=0, width=3, cursor="hand2").pack(side="right", padx=(6, 0))
            self._entry(cell, r["name"], 40, justify="left").pack(side="left", fill="x", expand=True)
            self._entry(b, r["cost"], 11).grid(row=g, column=1, padx=6)
            self._entry(b, r["margin"], 10).grid(row=g, column=2, padx=6)
            self._entry(b, r["prom"], 13, True).grid(row=g, column=3, padx=6)
            self._entry(b, r["bank"], 13, True).grid(row=g, column=4, padx=6)

        def total_row(rr, label, keys):
            tk.Label(b, text=label, bg="#FFF3C4", font=FONT_B, anchor="w", padx=4).grid(
                row=rr, column=0, sticky="ew", pady=2)
            for c, k in zip((1, 3, 4), keys):
                self._entry(b, self.d_tot[k], 13 if c > 1 else 11, True).grid(row=rr, column=c, padx=6, pady=2)
            tk.Label(b, text="", bg=CARD).grid(row=rr, column=2)

        total_row(n + 1, "Core Project Cost [A]", ("core_c", "core_p", "core_b"))
        total_row(n + 2, "Interest During Construction [B]  (100 % funded by promoters)",
                  ("idc_c", "idc_p", "idc_b"))
        total_row(n + 3, "Total Project Cost [A+B]", ("tot_c", "tot_p", "tot_b"))
        tk.Button(b, text="\uFF0B  Add Cost Item", command=self.add_item, bg=GREEN, fg="white", font=FONT_B,
                  relief="flat", bd=0, padx=14, pady=5, cursor="hand2").grid(
            row=n + 4, column=0, sticky="w", pady=(12, 2))
        tk.Label(b, text="How each item is depreciated (land, building, equipment) is set in the section "
                         "'Useful Life Assumed for Charging Depreciation' below.",
                 bg=CARD, fg="#777777", font=FONT_S, anchor="w", justify="left", wraplength=1050).grid(
            row=n + 5, column=0, columnspan=5, sticky="w")

    def _build_dep_items(self):
        """Depreciation treatment of each cost item - one row per item, follows the item list."""
        b = self.dep_items
        self._clear(b)
        b.columnconfigure(0, weight=1)
        heads = ("Depreciation treatment of each cost item", "Treatment", "Building Share (%)")
        for c, t in enumerate(heads):
            tk.Label(b, text=t, bg="#FFE0B2", fg="#E65100", font=FONT_B, padx=8, pady=3,
                     anchor="w" if c == 0 else "center").grid(row=0, column=c, sticky="ew", padx=1, pady=1)
        labels = [lbl for _k, lbl in CATS]
        for i, r in enumerate(self.rows):
            tk.Label(b, textvariable=r["name"], bg=CARD, font=FONT, anchor="w").grid(
                row=i + 1, column=0, sticky="ew", pady=3)
            ttk.Combobox(b, textvariable=r["cat"], values=labels, state="readonly",
                         width=28).grid(row=i + 1, column=1, padx=6)
            r["bshare_entry"] = self._entry(b, r["bshare"], 9)
            r["bshare_entry"].grid(row=i + 1, column=2, padx=6)
            self._sync_bshare(r)
        tk.Label(b, text="Land is not depreciated; Building and Equipment use the useful lives above; 'Shared' splits "
                         "the cost between the two by 'Building Share' (active only for Shared). "
                         "Interest during construction is shared 50:50. Depreciation stops when an asset's useful "
                         "life ends.",
                 bg=CARD, fg="#777777", font=FONT_S, anchor="w", justify="left", wraplength=1000).grid(
            row=len(self.rows) + 1, column=0, columnspan=3, sticky="w", pady=(6, 0))

    def _build_phasing_section(self):
        b = self.phase_body
        self._clear(b)
        nq = self.nq
        r0 = self._qheader(b, self.fy_dyn)
        for i, r in enumerate(self.rows):
            tk.Label(b, textvariable=r["name"], bg=CARD, font=FONT, anchor="w").grid(
                row=i + r0, column=0, sticky="w", pady=3)
            for q in range(nq - 1):
                self._entry(b, r["phase"][q], 8).grid(row=i + r0, column=q + 1, padx=3)
            self._entry(b, r["phase_last"], 8, True).grid(row=i + r0, column=nq, padx=3)
            self._calc_cell(b, tk.StringVar(value="100"), i + r0, nq + 1, True, "#FFF3C4")
        bar = tk.Frame(b, bg=CARD)
        bar.grid(row=len(self.rows) + r0, column=0, columnspan=nq + 2, sticky="w", pady=(12, 2))
        tk.Button(bar, text="\uFF0B  Add Quarter", command=self.add_quarter, bg=GREEN, fg="white", font=FONT_B,
                  relief="flat", bd=0, padx=14, pady=5, cursor="hand2").pack(side="left")
        tk.Button(bar, text="\uFF0D  Remove Last Quarter", command=self.remove_quarter, bg=ORANGE, fg="white",
                  font=FONT_B, relief="flat", bd=0, padx=14, pady=5, cursor="hand2").pack(side="left", padx=8)
        tk.Label(bar, textvariable=self.tenure_var, bg=CARD, fg=PRIMARY, font=FONT_B).pack(side="left", padx=12)
        tk.Label(b, text="Enter the % of each cost item spent in every quarter. The last quarter is the "
                         "balance (100 % less the other quarters), so each row always totals 100 %.",
                 bg=CARD, fg="#777777", font=FONT_S, anchor="w").grid(
            row=len(self.rows) + r0 + 1, column=0, columnspan=nq + 2, sticky="w")

    def _build_incurred_section(self):
        b = self.incurred_body
        self._clear(b)
        r0 = self._qheader(b, self.fy_dyn)
        U = self.dyn_updaters
        for i, r in enumerate(self.rows):
            self._q_row(b, i + r0, "", lambda R, q, i=i: R["cost_q"][i][q],
                        lambda R, i=i: sum(R["cost_q"][i]), U, label_var=r["name"])
        self._q_row(b, len(self.rows) + r0, "Total Cost Incurred", lambda R, q: R["tot_q"][q],
                    lambda R: sum(R["tot_q"]), U, bold=True)

    def _build_alloc_section(self):
        b = self.alloc_body
        self._clear(b)
        r0 = self._qheader(b, self.fy_dyn)
        U = self.dyn_updaters
        g = r0
        for i, r in enumerate(self.rows):
            tk.Label(b, textvariable=r["name"], bg="#EDE7F6", fg=PRIMARY, font=FONT_B, anchor="w",
                     padx=4).grid(row=g, column=0, columnspan=self.nq + 2, sticky="ew", pady=(6, 1))
            self._q_row(b, g + 1, "Promoter's Funding", lambda R, q, i=i: R["prom_q"][i][q],
                        lambda R, i=i: sum(R["prom_q"][i]), U, indent=True)
            self._q_row(b, g + 2, "Bank Finance", lambda R, q, i=i: R["bank_q"][i][q],
                        lambda R, i=i: sum(R["bank_q"][i]), U, indent=True)
            tv = tk.StringVar()
            U.append(lambda R, tv=tv, r=r: tv.set("Total " + r["name"].get().strip()))
            self._q_row(b, g + 3, "", lambda R, q, i=i: R["cost_q"][i][q],
                        lambda R, i=i: sum(R["cost_q"][i]), U, bold=True, label_var=tv)
            g += 4
        tk.Label(b, text="", bg=CARD).grid(row=g, column=0)
        self._q_row(b, g + 1, "Total Promoters Contribution", lambda R, q: R["prom_tot_q"][q],
                    lambda R: sum(R["prom_tot_q"]), U, bold=True)
        self._q_row(b, g + 2, "Total Bank Finance", lambda R, q: R["bank_tot_q"][q],
                    lambda R: sum(R["bank_tot_q"]), U, bold=True)
        self._q_row(b, g + 3, "Total Project Cost", lambda R, q: R["tot_q"][q],
                    lambda R: sum(R["tot_q"]), U, bold=True)

    def add_quarter(self):
        if self.nq >= MAX_QUARTERS:
            messagebox.showwarning(APP_TITLE, "The construction period can be at most %d quarters (%g years)."
                                   % (MAX_QUARTERS, MAX_QUARTERS / 4.0))
            return
        for r in self.rows:
            # the old balance quarter becomes an input holding its current value;
            # the new last quarter starts as the (zero) balance
            try:
                bal = max(0.0, 1.0 - sum(self._num(v.get(), "x", "pct", 0, 100) for v in r["phase"]))
            except ValueError:
                bal = 0.0
            nv = tk.StringVar(value=disp(bal, True))
            nv.trace_add("write", self._refresh_derived)
            r["phase"].append(nv)
        self.nq += 1
        self._rebuild_items()
        self._refresh_derived()
        self.status.set("Quarter added - construction period is now %d quarters." % self.nq)

    def remove_quarter(self):
        if self.nq <= 1:
            messagebox.showwarning(APP_TITLE, "The construction period needs at least one quarter.")
            return
        if not messagebox.askyesno(APP_TITLE, "Remove the last quarter (Q %s)?\n\nIts cost share is merged into "
                                   "the new last quarter, so every row still totals 100 %%."
                                   % ["I", "II", "III", "IV"][(self.nq - 1) % 4]):
            return
        for r in self.rows:
            r["phase"].pop()
        self.nq -= 1
        self._rebuild_items()
        self._refresh_derived()
        self.status.set("Quarter removed - construction period is now %d quarters." % self.nq)

    def add_item(self):
        if len(self.rows) >= MAX_ITEMS:
            messagebox.showwarning(APP_TITLE, "You can add at most %d cost items." % MAX_ITEMS)
            return
        self.rows.append(self._make_row(new_item("New cost item", 0.0, 0.25, "building", nq=self.nq)))
        self._rebuild_items()
        self._refresh_derived()
        self.status.set("Cost item added - rename it and enter its cost, margin and phasing.")

    def remove_item(self, idx):
        if len(self.rows) <= 1:
            messagebox.showwarning(APP_TITLE, "At least one cost item is required.")
            return
        name = self.rows[idx]["name"].get().strip() or "this item"
        if not messagebox.askyesno(APP_TITLE, "Remove the cost item '%s'?" % name):
            return
        del self.rows[idx]
        self._rebuild_items()
        self._refresh_derived()
        self.status.set("Cost item removed: " + name)

    def _update_inst_info(self, loan=None):
        """Frequency / size of each installment - needs only the tenure and installment inputs."""
        try:
            t = self._num(self.v["tenure"].get(), "x", "int", 1, MAX_YEARS)
            n = self._num(self.v["installments"].get(), "x", "int", 1, None)
        except ValueError:
            self.inst_info.set("")
            return
        if n > 12 * t:
            self.inst_info.set("Maximum %d installments for a %d-year tenure (12 a year)" % (12 * t, t))
            return
        if loan is not None:
            self._loan_cache = loan
        months = 12.0 * t / n
        freq = {1: "monthly", 3: "quarterly", 6: "half-yearly", 12: "yearly"}.get(months, "")
        text = "Installment every %g month%s%s   |   each installment = %s%% of the loan" % (
            round(months, 2), "" if months == 1 else "s", " (" + freq + ")" if freq else "",
            ("%.2f" % (100.0 / n)).rstrip("0").rstrip("."))
        if self._loan_cache is not None:
            text += " (Rs. %s Cr)" % "{:,.2f}".format(self._loan_cache / n)
        self.inst_info.set(text)

    def _update_fy_labels(self):
        self._update_inst_info()
        nq = self.nq
        ny = (nq + 3) // 4
        text = "Construction period: %d quarter%s (%g years)" % (nq, "" if nq == 1 else "s", nq / 4.0)
        try:
            y = self._num(self.v["start_fy"].get(), "x", "int", 1990, 2100)
        except ValueError:
            self.tenure_var.set(text)
            self.repay_info.set("")
            return
        self.tenure_var.set(text + "   |   operations begin in " + fy_label(y + ny))
        try:
            n = self._num(self.v["tenure"].get(), "x", "int", 1, MAX_YEARS)
            self.repay_info.set("Repayment: %d year%s  (%s to %s)" %
                                (n, "" if n == 1 else "s", fy_label(y + ny), fy_label(y + ny + n - 1)))
        except ValueError:
            self.repay_info.set("")
        for lst in (self.fy_static, self.fy_dyn):
            for lab, off in lst:
                try:
                    lab.configure(text=fy_label(y + off))
                except tk.TclError:
                    pass

    def _apply_updaters(self, R):
        for fn in self.static_updaters + self.dyn_updaters:
            fn(R)

    # ------------------------------------------------------------- form logic
    def _hook_traces(self):
        all_vars = [self.v_name] + list(self.v.values())
        for var in all_vars:
            var.trace_add("write", self._refresh_derived)

    def _num(self, s, label, kind="num", lo=None, hi=None):
        txt = str(s).strip().replace(",", "")
        if txt == "":
            raise ValueError("'%s' is empty." % label)
        try:
            v = float(txt)
        except ValueError:
            raise ValueError("'%s' must be a number (you entered '%s')." % (label, s))
        if v != v or v in (float("inf"), float("-inf")):
            raise ValueError("'%s' is not a valid number." % label)
        if lo is not None and v < lo:
            raise ValueError("'%s' must be at least %g." % (label, lo))
        if hi is not None and v > hi:
            raise ValueError("'%s' must not be more than %g." % (label, hi))
        if kind == "int":
            if not float(v).is_integer():
                raise ValueError("'%s' must be a whole number." % label)
            return int(v)
        if kind == "pct":
            return v / 100.0
        return v

    def get_assumptions(self):
        a = {"project_name": self.v_name.get().strip() or "Hotel Project"}
        for key, label, kind, unit, lo, hi in ALL_SCALARS:
            a[key] = self._num(self.v[key].get(), label, kind, lo, hi)
        if not self.rows:
            raise ValueError("Add at least one cost item.")
        items = []
        for i, r in enumerate(self.rows):
            name = r["name"].get().strip()
            if not name:
                raise ValueError("Cost item no. %d has no name." % (i + 1))
            cost = self._num(r["cost"].get(), "Total cost - " + name, "num", 0, None)
            margin = self._num(r["margin"].get(), "Margin requirement - " + name, "pct", 0, 100)
            cat = CAT_KEY.get(r["cat"].get(), "building")
            if cat == "shared":
                bshare = self._num(r["bshare"].get(), "Building share - " + name, "pct", 0, 100)
            else:
                try:
                    bshare = self._num(r["bshare"].get(), "x", "pct", 0, 100)
                except ValueError:
                    bshare = 0.5
            ph = [self._num(r["phase"][q].get(), "Phasing Q%d - %s" % (q + 1, name), "pct", 0, 100)
                  for q in range(len(r["phase"]))]
            if sum(ph) > 1.0 + 1e-9:
                raise ValueError("Cost phasing for '%s' adds up to more than 100 %%." % name)
            items.append({"name": name, "cost": cost, "margin": margin, "cat": cat,
                          "bshare": bshare, "phasing": ph})
        a["items"] = items
        a["quarters"] = self.nq
        if a["installments"] > 12 * a["tenure"]:
            raise ValueError("Number of installments cannot exceed 12 a year (monthly): for a tenure of %d year%s "
                             "the maximum is %d." % (a["tenure"], "" if a["tenure"] == 1 else "s", 12 * a["tenure"]))
        if a["room_share"] + a["fb_share"] > 1.0 + 1e-9:
            raise ValueError("Room revenue % + Food & beverage % must not exceed 100 %.")
        a["others_share"] = max(0.0, 1.0 - a["room_share"] - a["fb_share"])
        return a

    def _load_into_form(self, d):
        self._loading = True
        try:
            self.v_name.set(d["project_name"])
            for key, label, kind, unit, lo, hi in ALL_SCALARS:
                self.v[key].set(disp(d[key], kind == "pct"))
            self.nq = d["quarters"]
            self.rows = [self._make_row(it) for it in d["items"]]
            self._rebuild_items()
        finally:
            self._loading = False

    def _refresh_derived(self, *_):
        if self._loading:
            return
        # balancing quarter / year / revenue share
        for r in self.rows:
            try:
                s = sum(self._num(v.get(), "x", "pct", 0, 100) for v in r["phase"])
                r["phase_last"].set(disp(1.0 - s, True) if s <= 1.0 + 1e-9 else "over 100")
            except ValueError:
                r["phase_last"].set("?")
        try:
            r1 = self._num(self.v["room_share"].get(), "x", "pct", 0, 100)
            r2 = self._num(self.v["fb_share"].get(), "x", "pct", 0, 100)
            self.others_var.set(disp(1.0 - r1 - r2, True) if r1 + r2 <= 1.0 + 1e-9 else "over 100")
        except ValueError:
            self.others_var.set("?")
        self._update_fy_labels()
        # project cost table
        try:
            a = self.get_assumptions()
            R = compute(a)
        except ValueError:
            return
        f2 = lambda x: "{:,.2f}".format(x)
        for i, r in enumerate(self.rows):
            r["prom"].set(f2(R["prom_item"][i]))
            r["bank"].set(f2(R["bank_item"][i]))
        t = self.d_tot
        t["core_c"].set(f2(R["core"]))
        t["core_p"].set(f2(R["core_prom"]))
        t["core_b"].set(f2(R["core_bank"]))
        t["idc_c"].set(f2(R["idc"]))
        t["idc_p"].set(f2(R["idc"]))
        t["idc_b"].set(f2(0.0))
        t["tot_c"].set(f2(R["total_cost"]))
        t["tot_p"].set(f2(R["total_prom"]))
        t["tot_b"].set(f2(R["total_bank"]))
        self._update_inst_info(R["loan"])
        self._apply_updaters(R)

    # ------------------------------------------------------------ report logic
    def _fill_tree(self, tv, rows):
        tv.delete(*tv.get_children())
        ncols = max(len(r[2]) for r in rows)
        cols = ["c%d" % i for i in range(ncols + 1)]
        tv["columns"] = cols
        first = rows[0]
        for i, c in enumerate(cols):
            if i == 0:
                tv.heading(c, text=first[1], anchor="w")
                tv.column(c, width=400, minwidth=260, anchor="w", stretch=False)
            else:
                txt = first[2][i - 1] if i - 1 < len(first[2]) else ""
                tv.heading(c, text=txt, anchor="e")
                tv.column(c, width=98, minwidth=80, anchor="e", stretch=False)
        odd = False
        for kind, label, vals, f in rows[1:]:
            fl = f if isinstance(f, list) else [f] * max(1, len(vals))
            cells = [label]
            for i, v in enumerate(vals):
                cells.append(fmt_val(v, fl[i] if i < len(fl) else fl[-1]))
            cells += [""] * (ncols + 1 - len(cells))
            if kind == "row":
                tag = "odd" if odd else "even"
                odd = not odd
                cells[0] = "   " + cells[0]
            elif kind == "check":
                good = all(isinstance(v, (int, float)) and abs(v) < 1e-6 for v in vals)
                tag = "ok" if good else "bad"
            else:
                tag = kind
            tv.insert("", "end", values=cells, tags=(tag,))

    def generate_report(self, silent=False):
        try:
            a = self.get_assumptions()
        except ValueError as err:
            self.nb.select(self.tab_assump)
            messagebox.showerror(APP_TITLE, "Please correct the assumptions:\n\n" + str(err))
            return
        try:
            R = compute(a)
            IS, BS, CF = build_reports(a, R)
        except Exception as err:            # defensive: never crash the window
            messagebox.showerror(APP_TITLE, "Could not build the report:\n\n%s" % err)
            return
        self.a, self.R = a, R
        self.reports = (IS, BS, CF)
        self._fill_tree(self.tv_is, IS)
        self._fill_tree(self.tv_bs, BS)
        self._fill_tree(self.tv_cf, CF)
        self._update_dashboard()
        tally = max(abs(x) for x in R["diff"]) < 1e-6
        self.status.set("Report generated for '%s'   |   Total project cost Rs. %.2f Cr   |   "
                        "Balance sheet %s" % (a["project_name"], R["total_cost"],
                                              "tallies" if tally else "DOES NOT TALLY"))
        if not silent:
            self.nb.select(self.tab_dash)

    # -------------------------------------------------------------- toolbar ops
    def reset_defaults(self):
        if messagebox.askyesno(APP_TITLE, "Reset all assumptions to the case-study defaults?"):
            self._load_into_form(DEFAULTS)
            self._refresh_derived()
            self.generate_report(silent=True)
            self.status.set("Assumptions reset to defaults.")

    def save_assumptions(self):
        try:
            a = self.get_assumptions()
        except ValueError as err:
            messagebox.showerror(APP_TITLE, "Please correct the assumptions first:\n\n" + str(err))
            return
        path = filedialog.asksaveasfilename(
            title="Save assumptions", defaultextension=".json",
            filetypes=[("Assumption file", "*.json")], initialfile="assumptions.json")
        if not path:
            return
        data = {k: v for k, v in a.items() if k != "others_share"}
        try:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2)
            self.status.set("Assumptions saved to " + path)
        except OSError as err:
            messagebox.showerror(APP_TITLE, "Could not save the file:\n\n%s" % err)

    def _merge_loaded(self, loaded):
        """Copy only well-formed values from a loaded file onto the defaults."""
        if not isinstance(loaded, dict):
            raise ValueError("The file does not contain assumptions.")
        d = copy.deepcopy(DEFAULTS)
        isnum = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool)
        if isinstance(loaded.get("project_name"), str):
            d["project_name"] = loaded["project_name"][:80]
        for key, *_ in ALL_SCALARS:
            if isnum(loaded.get(key)):
                d[key] = loaded[key]
        # tenure / installments: must be whole numbers in range; older files (typed % row) get annual installments
        t = d["tenure"]
        if not (float(t).is_integer() and 1 <= t <= MAX_YEARS):
            t = DEFAULTS["tenure"]
            v = loaded.get("repay")
            if isinstance(v, list) and 0 <= len(v) < MAX_YEARS and all(isnum(x) for x in v):
                t = len(v) + 1
        d["tenure"] = int(t)
        i = d["installments"] if isnum(loaded.get("installments")) else d["tenure"]
        if not (float(i).is_integer() and 1 <= i <= 12 * d["tenure"]):
            i = d["tenure"]
        d["installments"] = int(i)

        raw = loaded.get("items")
        if raw is None and all(k in loaded for k in ("cost", "margin", "phasing")):
            # older file format (fixed five items) - keep the default names
            try:
                raw = []
                for i in range(len(loaded["cost"])):
                    base = DEFAULTS["items"][i] if i < len(DEFAULTS["items"]) else new_item()
                    raw.append({"name": base["name"], "cost": loaded["cost"][i],
                                "margin": loaded["margin"][i], "cat": base["cat"],
                                "bshare": 0.5, "phasing": loaded["phasing"][i]})
            except (IndexError, TypeError, KeyError):
                raw = None
        if isinstance(raw, list):
            items = []
            for it in raw[:MAX_ITEMS]:
                if not isinstance(it, dict):
                    continue
                ph = it.get("phasing")
                if (isinstance(it.get("name"), str) and it["name"].strip() and isnum(it.get("cost"))
                        and isnum(it.get("margin")) and isinstance(ph, list)
                        and len(ph) < MAX_QUARTERS and all(isnum(x) for x in ph)):
                    items.append({"name": it["name"].strip()[:80], "cost": it["cost"],
                                  "margin": it["margin"],
                                  "cat": it.get("cat") if it.get("cat") in CAT_LABEL else "building",
                                  "bshare": it["bshare"] if isnum(it.get("bshare")) else 0.5,
                                  "phasing": list(ph)})
            if items:
                d["items"] = items
                nq = loaded.get("quarters")
                if not (isnum(nq) and float(nq).is_integer() and 1 <= nq <= MAX_QUARTERS):
                    nq = len(items[0]["phasing"]) + 1          # older files: infer from the phasing rows
                d["quarters"] = int(nq)
        # every item must carry exactly (quarters - 1) phasing inputs
        nq = d["quarters"]
        for it in d["items"]:
            ph = list(it["phasing"])[:nq - 1]
            it["phasing"] = ph + [0.0] * (nq - 1 - len(ph))
        return d

    def load_assumptions(self):
        path = filedialog.askopenfilename(title="Load assumptions",
                                          filetypes=[("Assumption file", "*.json")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as fh:
                loaded = json.load(fh)
            d = self._merge_loaded(loaded)
        except (OSError, ValueError) as err:
            messagebox.showerror(APP_TITLE, "Could not read the file:\n\n%s" % err)
            return
        self._load_into_form(d)
        self._refresh_derived()
        self.generate_report(silent=True)
        self.status.set("Assumptions loaded from " + path)

    def export_excel(self):
        try:
            a = self.get_assumptions()
        except ValueError as err:
            messagebox.showerror(APP_TITLE, "Please correct the assumptions first:\n\n" + str(err))
            return
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
            from openpyxl.utils import get_column_letter
        except ImportError:
            messagebox.showerror(APP_TITLE, "Excel export needs the 'openpyxl' library.\n\n"
                                 "Open CMD and run:\n    python -m pip install openpyxl")
            return
        path = filedialog.asksaveasfilename(
            title="Export reports to Excel", defaultextension=".xlsx",
            filetypes=[("Excel workbook", "*.xlsx")], initialfile="Detailed_Project_Report.xlsx")
        if not path:
            return
        R = compute(a)
        IS, BS, CF = build_reports(a, R)
        sheets = [("Assumption Sheet", assumption_rows(a, R)),
                  ("Project Income Statement", IS),
                  ("Projected Balance Sheet", BS),
                  ("Projected Cash Flow Statement", CF)]
        numfmt = {"num": '#,##0.00;[Red]-#,##0.00', "num0": '#,##0', "pct": '0.00%',
                  "x": '0.00"x"', "yrs": '0.00" years"', "int": '0', "text": '@'}
        fills = {"head": ("4527A0", "FFFFFF"), "section": ("EDE7F6", "4527A0"),
                 "total": ("FFF3C4", "000000"), "grand": ("C8E6C9", "000000"),
                 "check": ("C8E6C9", "1B5E20")}
        try:
            wb = openpyxl.Workbook()
            wb.remove(wb.active)
            for name, rows in sheets:
                ws = wb.create_sheet(name)
                ws.cell(row=1, column=1, value="%s  -  %s" % (a["project_name"], name)).font = Font(bold=True, size=14, color="4527A0")
                r = 3
                for kind, label, vals, f in rows:
                    ws.cell(row=r, column=1, value=label)
                    fl = f if isinstance(f, list) else [f] * max(1, len(vals))
                    for i, v in enumerate(vals):
                        c = ws.cell(row=r, column=i + 2, value=v)
                        if not isinstance(v, str):
                            c.number_format = numfmt.get(fl[i] if i < len(fl) else fl[-1], "General")
                        c.alignment = Alignment(horizontal="right")
                    if kind in fills:
                        bg, fg = fills[kind]
                        for col in range(1, max(len(vals), 1) + 2):
                            cell = ws.cell(row=r, column=col)
                            cell.fill = PatternFill("solid", start_color=bg, end_color=bg)
                            cell.font = Font(bold=True, color=fg)
                    elif kind == "note":
                        ws.cell(row=r, column=1).font = Font(italic=True, color="777777")
                    r += 1
                ws.column_dimensions["A"].width = 56
                for col in range(2, 40):
                    ws.column_dimensions[get_column_letter(col)].width = 14
                ws.freeze_panes = "B4"
            wb.save(path)
        except (OSError, PermissionError) as err:
            messagebox.showerror(APP_TITLE, "Could not write the Excel file (is it open in Excel?):\n\n%s" % err)
            return
        self.status.set("Exported to " + path)
        messagebox.showinfo(APP_TITLE, "Reports exported successfully:\n" + path)


# --------------------------------------------------------------------------
def main():
    try:                                    # sharper text on high-DPI Windows screens
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()
